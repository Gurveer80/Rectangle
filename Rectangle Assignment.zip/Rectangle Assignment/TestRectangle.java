/*
  Gurveer Singh
  Professor Satyndra Narayen
  Date 10 April 2020
*/
/**
   Rectangle Assignment
   @author Gurveer Singh
   @version 1.1

*/
public class TestRectangle
{
  public static void main (String [] args)
  {
    Rectangle result1 = new Rectangle(); // calling default constructor
    System.out.println(result1);

       Rectangle result2 = new Rectangle(15, 16);// calling two argument constructor
       System.out.println(result2);

       System.out.println("New Length="+result1.getLength());
       System.out.println("New Width="+result1.getWidth());

       System.out.println("Area of Rectangle="+result2.area());
       System.out.println("Perimeter of Rectangle="+result2.perimeter());

       result1.setLength(13.0);
       result1.setWidth(14.0);

       Rectangle []array = new Rectangle[10]; // creating an array
       int  i;
       for( i=0;i<array.length;i++)// loading an array
       {
		   array[i]=  new Rectangle(i+5,i+2);
		    System.out.println(array[i]);
       }

       Rectangle result3 = new Rectangle();
       Rectangle result4 = new Rectangle(10,2);
       System.out.println(result3.equals(result4)); // equals method

  }
}