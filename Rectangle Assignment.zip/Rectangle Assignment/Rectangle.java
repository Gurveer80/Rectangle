/*
  Gurveer Singh
  Professor Satyndra Narayen
  Date 10 April 2020
*/
/**
   Rectangle Assignment
   @author Gurveer Singh
   @version 1.1

*/

public class Rectangle
{
  final private double lw=10.0; // constant variable
  private double length;
  private double width;

/**
default constructor
*/
  public Rectangle()
  {
    length= lw;
    width = lw;
  }
/**
Rectangle constructor with two arguments
@param length,width
*/
  public Rectangle(double length, double width)
  {
    this.length =length;
    this.width= width;
  }
/**
Set length method with one arguments
@param length
@return void
*/
  public void setLength(double length)
  {
    this.length =length;
  }
/**
Set width method with one arguments
@param width
@return void
*/
  public void setWidth( double width)
  {
    this.width =width;
  }
/**
Set length width method with two arguments
@param width, length
@return void
*/
  public void setMethod(double length, double width) // two arguments
  {
    this.length =length;
    this.width= width;
  }
 /**
get length method which return length
@param length
@return double
*/
   public double getLength()
   {
    return this.length;
   }
/**
get width method which return width
@param width
@return double
*/
   public double getWidth()
   {
    return this.width;
   }
 /**
Area method which return area of rectangle
@return double
*/
   public double area()
   {
     double area = length*width;
     return area;
   }
 /**
Perimeter method which return perimeter of rectangle
@return double
*/
   public double perimeter()
   {
     double perimeter= 2*(length+width);
     return perimeter;
   }
/**
tostring method
@return String
*/
   public String toString()
   {
     return("Length="+length+"  Width="+width);
   }
 /**
Equals method which will compare two objects
@return double
*/
   public boolean equals(Object obj)
   {
     Rectangle r =(Rectangle)obj;
     return (this.length==r.length && this.width==r.width);
   }

}